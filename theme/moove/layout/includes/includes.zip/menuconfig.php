<?php

$menu = array();

$menus[] = array(
    'key' => 'mycourses',
	'title' => 'My Course',
	'url' => '#',
	'fa' => 'fa-graduation-cap',
	'flag' => array(
		array(
			'key' => 'mycourses',
			'title' => 'My Courses',
			'url' => 'http://10.0.0.8/moodle32/course/index.php'
		),
		array(
			'key'=> 'assignedcourses',
			'title' =>'Assigned Courses',
			'url' => 'http://10.0.0.8/moodle32/my/listcourse.php?section=assigned'
		)
	)
);

$menus[] = array(
    'key' => 'mycourses',
	'title' => 'My Course',
	'url' => '#',
	'fa' => 'fa-graduation-cap',
	'flag' => array(
		array(
			'key' => 'mycourses',
			'title' => 'My Courses',
			'url' => 'http://10.0.0.8/moodle32/course/index.php'
		),
		array(
			'key'=> 'assignedcourses',
			'title' =>'Assigned Courses',
			'url' => 'http://10.0.0.8/moodle32/my/listcourse.php?section=assigned'
		)
	)
);












