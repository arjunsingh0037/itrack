moodle-local_getkey
===================

Moodle - Get API Key from Vidya.io


ABOUT

This Moodle plugin is to register API key required by other modules.

USAGE

This local plugin allows you to get API key required for:  
Moodle local plugin local_vmchat (footer chat)  
Moodle plugin mod_onetoone (whiteboard)  
Moodle module mod_fastchat (Very fast chat replacing Moodle's default chat module)


INSTALLATION

1) Place the getkey directory inside your Moodle's local directory.  
2) Go to Site Administration -> notification area to install plugin   
3) Browse to Site Administration->Get key   
4) Fill form and click on submit button to get API key.   


Changelog v 1.2

1) Statistics for Message and users
2) If you already have API key, No need to fill form, You can directly save the existing key.
3) Opting added to delete existing key.  